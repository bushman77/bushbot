# MQElixir

One Paragraph project description goes here

## Getting Started

Quick start instructions to get users up and going

```txt
/plugin MQElixir
```

### Commands

Describe the commands available and how to use them.

```txt
Give examples
```

### Configuration File

Describe the configuration file and what the settings do

```yaml
- Example goes here
```

## Other Notes

Add additional notes

## Authors

* **Your name** - *Initial work*

See also the list of [contributors](https://github.com/your/project/contributors) who participated in this project.

## Acknowledgments

* Inspiration from...
* I'd like to thank the Thieves' Guild for helping me with all the code I stole...
