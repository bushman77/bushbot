#undef min
#undef max

#define WIN32_LEAN_AND_MEAN

#include <mq/Plugin.h>

#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>

#include <string>
#include <unordered_map>
#include <mutex>
std::mutex connectionMutex;

#pragma comment(lib, "Ws2_32.lib")

#define ELIXIR_SERVER "127.0.0.1"
#define ELIXIR_PORT "4000"



struct CharacterConnection {
	SOCKET socket;
	bool connected;
};

std::unordered_map<std::string, CharacterConnection> connections;

void ConnectToElixir(std::string characterName) {
	std::lock_guard<std::mutex> lock(connectionMutex);
	auto it = connections.find(characterName);
	if (it != connections.end() && it->second.connected) {
		WriteChatf("[MQ2Elixir] %s is already connected.", characterName.c_str());
		return;
	}

	struct addrinfo* result = NULL, hints = {};
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;

	if (getaddrinfo(ELIXIR_SERVER, ELIXIR_PORT, &hints, &result) != 0) {
		WriteChatf("[MQ2Elixir] Failed to resolve server address.");
		return;
	}

	SOCKET sock = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
	if (sock == INVALID_SOCKET) {
		WriteChatf("[MQ2Elixir] Failed to create socket.");
		freeaddrinfo(result);
		return;
	}

	if (connect(sock, result->ai_addr, (int)result->ai_addrlen) == SOCKET_ERROR) {
		WriteChatf("[MQ2Elixir] Connection failed with error: %d", WSAGetLastError());
		closesocket(sock);
		freeaddrinfo(result);
		return;
	}

	freeaddrinfo(result);
	connections[characterName] = { sock, true };
	WriteChatf("[MQ2Elixir] %s connected to Elixir server.", characterName.c_str());
}


void DisconnectFromElixir(std::string characterName) {
	std::lock_guard<std::mutex> lock(connectionMutex);
	auto it = connections.find(characterName);
	if (it == connections.end() || !it->second.connected) {
		WriteChatf("[MQ2Elixir] %s is not connected.", characterName.c_str());
		return;
	}

	closesocket(it->second.socket);
	connections.erase(it);
	WriteChatf("[MQ2Elixir] %s disconnected.", characterName.c_str());
}

void ListConnectedCharacters() {
	WriteChatf("[MQ2Elixir] Connected Characters:");
	for (const auto& entry : connections) {
		if (entry.second.connected) {
			WriteChatf("- %s", entry.first.c_str());
		}
	}
}

void ElixirCommand(PSPAWNINFO pChar, PCHAR szLine) {
	std::string command(szLine);
	std::string characterName = GetCharInfo()->Name;

	if (command == "connect") {
		ConnectToElixir(characterName);
	}
	else if (command == "disconnect") {
		DisconnectFromElixir(characterName);
	}
	else if (command == "names") {
		ListConnectedCharacters();
	}
	else {
		WriteChatf("[MQ2Elixir] Unknown command: %s", szLine);
	}
}

PLUGIN_API void InitializePlugin() {
	WSAData wsaData;
	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
		WriteChatf("[MQ2Elixir] WSAStartup failed.");
		return;
	}
	AddCommand("/elixir", ElixirCommand);
}


PLUGIN_API void ShutdownPlugin() {
	std::lock_guard<std::mutex> lock(connectionMutex);
	for (auto& entry : connections) {
		if (entry.second.connected) {
			closesocket(entry.second.socket);
		}
	}
	connections.clear();
	WSACleanup();
	RemoveCommand("/elixir");
}

